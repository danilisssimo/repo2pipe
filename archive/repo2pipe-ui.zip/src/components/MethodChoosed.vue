<template>
    <div class="input-container">
        <InputTextComponent id="git-link" class="shadow" v-show="showLink" type="text" placeholder="Ссылка на репозиторий"
            :isValid="isInputValid"
            @onInput="(e:string) => { link = e }"
            @onChoose="() => { showArchive = false }">
            <font-awesome-icon icon="fa-solid fa-link" />
        </InputTextComponent>
        <InputFileComponent id="git-tar" class="shadow" v-show="showArchive" type="file" placeholder="Выберите архив репозитория"
            :isValid="isInputValid"
            @onInput="(e:string) => { file = e }"
            @onChoose="() => { showLink = false }">
            <font-awesome-icon icon="fa-solid fa-file-zipper" />
        </InputFileComponent>
    </div>
</template>

<script lang="ts">
//eslint-disable-next-line
const httpReg = /^https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/=]*)$/

import InputFileComponent from './forms/InputFileComponent.vue';
import InputTextComponent from '@/components/forms/InputTextComponent.vue';
import { TransitionScale } from '@morev/vue-transitions';
import { defineComponent } from 'vue';

export default defineComponent({
    name: 'MethodChoosed',
    props: ['onValdatedLink', 'onLink'],
    watch: {
        link: {
            handler(value) {
                this.$emit("onLink", value);
                this.isInputValid = httpReg.test(value)
                console.log(this.isInputValid)
                this.$emit("onValidatedLink", this.isInputValid);
            }
        },
        file: {
            handler(value) {
                this.$emit("onLink", value);
                this.isInputValid = value != ""
                console.log(this.isInputValid)
                this.$emit("onValidatedLink", this.isInputValid);
            }
        }
    },
    data() {
        return {
            showArchive: true,
            showLink: true,
            isInputValid: false,
            link: "",
            file: ""
        }
    },
    components: { InputTextComponent, InputFileComponent, TransitionScale }
})
</script>

<style scoped>
.input-container {
    position: relative;
    display: flex;
    justify-content: center;
    min-width: 400px;
    gap: 10px;
    transition: all 0.2s;
}
</style>
