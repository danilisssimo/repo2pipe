<template>
  <div class="state-visualizer">
    <div class="states-container">
      <div
        v-for="(state, index) in states" :key="state.data.name" :class="['state-item', getStatusClass(state.status)]">
        <div class="state-content">
          <div class="state-name">{{ state.data.name }}</div>
          <div class="state-description">{{ state.data.description }}</div>
          <div class="state-timings" v-if="state.data.startTime">
            <div>Start: {{ formatTime(state.data.startTime) }}</div>
            <div v-if="state.data.endTime">
              End: {{ formatTime(state.data.endTime) }}
              <span v-if="state.data.duration">
                ({{ state.data.duration }}ms)
              </span>
            </div>
          </div>
        </div>
        <div class="state-connector" v-if="index < states.length - 1">
          <div class="connector-line"></div>
          <div class="connector-arrow">→</div>
        </div>
      </div>
    </div>
    
    <div class="controls" v-if="showControls">
      <button @click="previous" :disabled="!canGoPrevious">Previous</button>
      <button @click="next" :disabled="!canGoNext">Next</button>
      <button @click="completeCurrent">Complete</button>
      <button @click="failCurrent">Fail</button>
      <button @click="resetAll">Reset</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { StateManager } from '@/assets/js/states/StateManager';
import { StatusCodes } from '@/assets/js/states/utils';
import type { StateObject } from '@/assets/js/states/utils';

interface Props {
  states: StateObject[];
  showControls?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  showControls: true
});

const stateManager = ref<StateManager>(
  new StateManager(props.states, {
    onStateChange: (name, status) => {
      console.log(`State ${name} changed to ${StatusCodes[status]}`);
    }
  })
);

const states = computed(() => stateManager.value.getStatesWithStatus());
const currentState = computed(() => stateManager.value.getCurrentState());

const canGoPrevious = computed(() => currentState.value?.prev !== null);
const canGoNext = computed(() => currentState.value?.next !== null);

const getStatusClass = (status: StatusCodes) => {
  switch (status) {
    case StatusCodes.WAITING: return 'waiting';
    case StatusCodes.PROCESSING: return 'processing';
    case StatusCodes.COMPLETED: return 'completed';
    case StatusCodes.FAILED: return 'failed';
    default: return '';
  }
};

const formatTime = (date: Date | null): string => {
  if (!date) return '';
  return date.toLocaleTimeString();
};

const previous = () => stateManager.value.previous();
const next = () => stateManager.value.next();
const completeCurrent = () => stateManager.value.completeCurrent();
const failCurrent = () => stateManager.value.failCurrent();
const resetAll = () => stateManager.value.resetAll();

// Start the state machine
stateManager.value.start();
</script>

<style scoped>
.state-visualizer {
  padding: 20px;
}

.states-container {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 20px;
}

.state-item {
  display: flex;
  align-items: center;
  gap: 10px;
}

.state-content {
  padding: 15px;
  border: 2px solid #ccc;
  border-radius: 8px;
  min-width: 150px;
  text-align: center;
}

.state-name {
  font-weight: bold;
  margin-bottom: 5px;
}

.state-description {
  font-size: 0.9em;
  color: #666;
}

.state-timings {
  font-size: 0.8em;
  color: #888;
  margin-top: 5px;
}

.state-connector {
  display: flex;
  align-items: center;
}

.connector-line {
  width: 30px;
  height: 2px;
  background: #ccc;
}

.connector-arrow {
  color: #ccc;
}

/* Status styles */
.waiting .state-content {
  background: #f5f5f5;
  border-color: #ddd;
}

.processing .state-content {
  background: #e3f2fd;
  border-color: #2196f3;
  animation: pulse 1.5s infinite;
}

.completed .state-content {
  background: #e8f5e8;
  border-color: #4caf50;
}

.failed .state-content {
  background: #ffebee;
  border-color: #f44336;
}

@keyframes pulse {
  0% { opacity: 1; }
  50% { opacity: 0.7; }
  100% { opacity: 1; }
}

.controls {
  display: flex;
  gap: 10px;
  justify-content: center;
}

.controls button {
  padding: 8px 16px;
  border: 1px solid #ccc;
  border-radius: 4px;
  background: white;
  cursor: pointer;
}

.controls button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.controls button:hover:not(:disabled) {
  background: #f0f0f0;
}
</style>