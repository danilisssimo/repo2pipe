<template>
    <div :class="['status-container', getClassOfStatus(status)]">
        {{ stateNumber }}
    </div>
</template>

<script lang="ts">

import { StatusCodes } from '@/assets/js/states/utils';

export default {
    name: "StateIco",
    props: { 
        status: StatusCodes, 
        stateNumber: Number,
    },
    methods: {
        getClassOfStatus(status: StatusCodes) {
            switch(status) {
                case StatusCodes.WAITING: return "gray shadow"
                case StatusCodes.PROCESSING: return "purple"
                case StatusCodes.COMPLETED: return "green"
                case StatusCodes.FAILED: return "red"
                default: return "gray"
            }
        }
    },
}
</script>

<style scoped>
.status-container {
    border-radius: 20px;
    width: 24px;
    height: 24px;
    padding: 10px;
}
</style>