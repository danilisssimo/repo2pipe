<template>
    <button class="purple" :disabled="disabled" @click="throwClickEvent">
        <slot></slot>
    </button>
</template>

<script lang="ts">
export default {
    name: "ButtonComponent",
    emits: ["onClick"],
    methods: {
        throwClickEvent() {
            this.$emit("onClick")
        }
    },
    props:{ disabled: Boolean }
}
</script>

<style scoped>
button {
    min-width: 24px;
    min-height: 24px;
    padding: 10px;
    border-radius: var(--border-radius-default);
    outline: none;
}

button:disabled, 
button:disabled:active, 
button:disabled:hover {
    border: var(--lt-gray) solid;
    background-color: var(--white);
    color: var(--lt-gray);
    transition: all 0.2s;
}

.purple:hover {
    border: var(--dk-purple) solid;
    background-color: var(--purple);
    color: var(--xdk-purple);
    transition: all 0.2s;
}

.purple:active {
    border: var(--xdk-purple) solid;
    background-color: var(--lt-purple);
    color: var(--dk-purple);
    transition: all 0.2s;
}
</style>