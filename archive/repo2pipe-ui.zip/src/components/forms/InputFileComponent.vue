<template>
    <div 
      :class="['container__input']"
      @click="clickOnInput">
      <div :class="[
        'logo', 
        showInput ? 'logo-small' : 'purple logo-medium',
        isValid || !showInput ? 'enabled-logo' : 'disabled-logo'
        ]">
        <slot></slot>
      </div>
      
      <label v-show="showInput"
        :class="[isValid ? 'valid-input' : 'invalid-input']">
        <input type="file" :id="id" accept=".tar, .zip, .rar, .gz, .lz, .7z"
          @change="changeFile">
        <span class="placeholder" :style="{color: isValid ? 'var(--dk-purple)' : ''}">
          {{value || placeholder}}
        </span>
      </label>
    </div>
</template>

<script lang="ts">

export default {
  name: 'InputFileComponent',
  data() {
    return {
      value: "", showInput: false
    }
  },
  emits: ['onInput', 'onChoose'],
  watch: {
    value: {
      handler(input) { this.$emit("onInput", input); }
    }
  },
  props: {
    id: String,
    placeholder: String,
    inputValue: [String],
    isValid: Boolean
  },
  methods: {
    clickOnInput() {
      if (this.showInput) { return }
      this.showInput = !this.showInput
      this.$emit("onChoose")
    },
    changeFile(event:Event) {
      if (event && event.target && event.target.files.length > 0) {
        this.value = event.target.files[0].name
        this.$emit("onInput", this.value)
      }
    }
  }
}
</script>

<style scoped>
@import url("./index.css");

.placeholder {
  color: var(--gray); 
}

label input[type=file] {
	display: none;
}
/* .disabled-logo { color: var(--gray); transition: all 0.2s; } */
.invalid-input { border: var(--gray) solid; color: var(--gray); transition: all 0.2s; }
  
label {
  display: flex;
  align-items: center;
  border: var(--gray) solid;
  padding-left: 40px;
}
</style>