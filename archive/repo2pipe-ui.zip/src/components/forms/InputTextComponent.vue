<template>
    <div 
      :class="['container__input']"
      @click="clickOnInput">
      <div :class="[
        'logo', 
        showInput ? 'logo-small' : 'purple logo-medium',
        isValid || !showInput ? 'enabled-logo' : 'disabled-logo'
        ]">
        <slot></slot>
      </div>
      
      <input v-show="showInput" v-model="value" type="text"
        :id="id"
        :placeholder="placeholder"
        :style="{paddingLeft: '40px'}"
        :class="[isValid ? 'valid-input' : 'invalid-input']">
    </div>
</template>

<script lang="ts">

export default {
  name: 'InputTextComponent',
  data() {
    return {
      value: this.inputValue,
      showInput: false
    }
  },
  emits: ['onInput', 'onChoose'],
  watch: {
    value: {
      handler(input) { this.$emit("onInput", input); }
    }
  },
  props: {
    id: String,
    placeholder: String,
    type: String,
    inputValue: [String],
    isValid: Boolean
  },
  methods: {
    clickOnInput() {
      if (this.showInput) { return }
      this.showInput = !this.showInput
      this.$emit("onChoose")
    }
  }
}
</script>

<style scoped>
@import url("./index.css");
</style>