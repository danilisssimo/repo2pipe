<template>
  <div class="top-app">
    <h1 id="app-title">
      {{ appName }}
    </h1>
    <div class="top-input-container">
      <MethodChoosed
      @onValidatedLink="(e:boolean) => { 
        buttonDisabled = !e
        console.log('button', buttonDisabled)
      }"></MethodChoosed>
      <div class="btn-container">
        <TransitionSlide :offset="[-20, 0]">
          <ButtonComponent v-show="!buttonDisabled" :disabled="buttonDisabled"
            @on-click="startGenerate"
            class="shadow" style="height: 100%;">
            <div class="logo">
              <font-awesome-icon icon="fa-solid fa-play" />
            </div>
          </ButtonComponent>
        </TransitionSlide>
      </div>
    </div>
  </div>

  <div class="bottom-app">
    <div class="states-container" v-if="states">
      <StateIco v-for="value, index of states.getStatesWithStatus()"
        :status="value.status"
        :stateNumber="index+1">
      </StateIco>
    </div>
  </div>
</template>

<script lang="ts">
import { StateManager }  from './assets/js/states/StateManager';
import { StatusCodes } from './assets/js/states/utils';
import { TransitionSlide } from '@morev/vue-transitions';
import ButtonComponent from './components/forms/ButtonComponent.vue';
import MethodChoosed from './components/MethodChoosed.vue';
import StateIco from './components/ico/StateIco.vue';

export default {
  name: 'App',
  data() {
    return {
      appName: "Repo2Pipe",
      statuses: StatusCodes,
      buttonDisabled: true,
      link: "",
      states: null
    }
  },
  methods: {
    startGenerate() {
      this.states = new StateManager(
      [
          {"name":"Installing", "description": ""},
          {"name":"Prepare", "description": ""},
          {"name":"Search", "description": ""},
          {"name":"Build", "description": ""},
          {"name":"Generate", "description": ""},
        ]
      )
      console.log("START GEN", this.link)
    }
  },
  components: {
    ButtonComponent,
    TransitionSlide,
    StateIco, MethodChoosed
  }
}
</script>

<style>
@import url("./assets/styles/index.css");

.top-input-container {
  display: flex;
  position: relative;
}

.states-container {
  display: flex;
  gap: 20px;
  padding: 20px;
}

.btn-container { 
  height: 100%;
  position: absolute; 
  right: -60px;
}

.svg-inline--fa { height: 2em; }
.top-app { justify-content: flex-end; }
.bottom-app { justify-content: flex-start; }
.top-app, .bottom-app {
  text-align: center;
  align-items: center;
  display: flex;
  flex-direction: column;
  height: 100%;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  font-size: 400;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  position: fixed;
  top: 0;
  bottom: 0;
  right: 0;
  left: 0;
  height: 100%;
  display: flex;
  flex-direction: column;
}
</style>
