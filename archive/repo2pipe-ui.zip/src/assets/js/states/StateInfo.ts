import type { StateInfoData } from './utils';

export class StateInfo implements StateInfoData {
    name: string;
    description: string;
    startTime: Date | null;
    endTime: Date | null;
    duration: number | null;

    constructor(name: string, description: string) {
        this.name = name;
        this.description = description;
        this.startTime = null;
        this.endTime = null;
        this.duration = null;
    }

    saveStartTime(): void {
        this.startTime = new Date();
    }

    saveEndTime(): void {
        this.endTime = new Date();
        if (this.startTime) {
            this.duration = this.endTime.getTime() - this.startTime.getTime();
        }
    }

    toObject(): StateInfoData {
        return {
            name: this.name,
            description: this.description,
            startTime: this.startTime,
            endTime: this.endTime,
            duration: this.duration
        };
    }
}