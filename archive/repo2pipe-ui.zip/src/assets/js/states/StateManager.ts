import { State } from '@/assets/js/states/State';
import { StateInfo } from '@/assets/js/states/StateInfo';
import { StatusCodes } from '@/assets/js/states/utils';
import type { StateObject, StateManagerOptions } from '@/assets/js/states/utils';

export class StateManager {

  private head: State | null;
  private current: State | null;
  private onStateChange?: (stateName: string, status: number) => void;

  constructor(data: StateObject[], options: StateManagerOptions = {}) {
    this.head = null;
    this.current = null;
    this.onStateChange = options.onStateChange;

    if (data.length === 0) return;

    this.initializeList(data);
    
    if (options.autoStartFirst) {
      this.start();
    }
  }

  private initializeList(data: StateObject[]): void {
    // Create head
    this.head = new State(new StateInfo(data[0].name, data[0].description));
    let currentState = this.head;

    // Create remaining nodes
    for (let i = 1; i < data.length; i++) {
      const newNode = new State(
        new StateInfo(data[i].name, data[i].description),
        null,
        currentState
      );
      
      currentState.next = newNode;
      currentState = newNode;
    }

    this.current = this.head;
  }

  // Navigation methods
  start(): void {
    if (this.head) {
      this.current = this.head;
      this.head.changeStatusToProcessing();
      this.notifyStateChange(this.head.data.name, this.head.status);
    }
  }

  next(): boolean {
    if (!this.current?.next) return false;

    if (this.current.status === StatusCodes.PROCESSING) {
      this.current.changeStatusToCompleted();
      this.notifyStateChange(this.current.data.name, this.current.status);
    }

    this.current = this.current.next;
    this.current.changeStatusToProcessing();
    this.notifyStateChange(this.current.data.name, this.current.status);

    return true;
  }

  previous(): boolean {
    if (!this.current?.prev) return false;

    this.current.reset();
    this.notifyStateChange(this.current.data.name, this.current.status);

    this.current = this.current.prev;
    this.current.changeStatusToProcessing();
    this.notifyStateChange(this.current.data.name, this.current.status);

    return true;
  }

  // Status management
  completeCurrent(): void {
    if (this.current) {
      this.current.changeStatusToCompleted();
      this.notifyStateChange(this.current.data.name, this.current.status);
    }
  }

  failCurrent(): void {
    if (this.current) {
      this.current.changeStatusToFailed();
      this.notifyStateChange(this.current.data.name, this.current.status);
    }
  }

  resetAll(): void {
    let current = this.head;
    while (current) {
      current.reset();
      this.notifyStateChange(current.data.name, current.status);
      current = current.next;
    }
    this.current = this.head;
  }

  // Getters
  getCurrentState(): State | null {
    return this.current;
  }

  getStatesList(): StateInfo[] {
    const result: StateInfo[] = [];
    let current = this.head;

    while (current) {
      result.push(current.data);
      current = current.next;
    }

    return result;
  }

  getStatesWithStatus(): Array<{ data: StateInfo; status: StatusCodes }> {
    const result: Array<{ data: StateInfo; status: StatusCodes }> = [];
    let current = this.head;

    while (current) {
      result.push({
        data: current.data,
        status: current.status
      });
      current = current.next;
    }

    return result;
  }

  isCompleted(): boolean {
    let current = this.head;
    while (current) {
      if (current.status !== StatusCodes.COMPLETED && current.next === null) {
        return false;
      }
      current = current.next;
    }
    return true;
  }

  private notifyStateChange(stateName: string, status: number): void {
    if (this.onStateChange) {
      this.onStateChange(stateName, status);
    }
  }
}