export interface StateObject {
  name: string;
  description: string;
}

export interface StateInfoData {
  name: string;
  description: string;
  startTime: Date | null;
  endTime: Date | null;
  duration: number | null;
}

export interface StateManagerOptions {
  autoStartFirst?: boolean;
  onStateChange?: (stateName: string, status: number) => void;
}

export enum StatusCodes {
  WAITING = 0,
  PROCESSING = 1,
  COMPLETED = 2,
  FAILED = 3
}