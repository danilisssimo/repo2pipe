
export interface StateObject {
    name:string
    description: string
}


export default class StateManager {
    head: State

    constructor(data: StateObject[]) {
        if (data.length === 0) {
            this.head = null;
            return;
        }

        // Создаем голову списка
        this.head = new State(
            new StateInfo(data[0].name, data[0].description), 
            null, 
            null
        );

        let currentState = this.head;
        
        // Создаем остальные узлы
        for (let index = 1; index < data.length; index++) {
            const newNode = new State(
                new StateInfo(data[index].name, data[index].description), 
                null, 
                currentState  // prev ссылается на текущий узел
            );
            
            // Связываем текущий узел с новым
            currentState.next = newNode;
            
            // Перемещаемся к новому узлу
            currentState = newNode;
        }
    }

    getStatesList() {
        let tempHead = this.head
        let result = []
        while (tempHead.next != null) {
            result.push(tempHead.data)
            tempHead = tempHead.next
        }
        result.push(tempHead.data)
        return result
    }
}

class StatusCodes {
    static processing:number = 0
    static completed:number = 1
    static failed:number = 2
    static waiting:number = 3
}

class StateInfo {
    name: string
    description: string
    startTime: Date
    endTime: Date

    constructor(name: string, description: string) {
        this.name = name;
        this.description = description;
        this.startTime = null;
        this.endTime = null;
    }
    saveStartTime() { this.startTime = new Date() }
    saveEndTime() { this.endTime = new Date() }
}

class State {
    data: StateInfo
    status: number
    next: State
    prev: State
    constructor(data: StateInfo, nextState: State, prevState: State) {
        this.data = data
        this.status = StatusCodes.waiting
        this.next = nextState
        this.prev = prevState
    }

    changeStatusToProcessing() { 
        this.data.saveStartTime()
        this.status = StatusCodes.processing
    }
    changeStatusToComplete() { this.status = StatusCodes.completed }
    changeStatusToFalse() { this.status = StatusCodes.failed }
}
