import { StateInfo } from '@/assets/js/states/StateInfo';
import { StatusCodes } from '@/assets/js/states/utils';

export class State {
  data: StateInfo;
  status: StatusCodes;
  next: State | null;
  prev: State | null;

  constructor(data: StateInfo, nextState: State | null = null, prevState: State | null = null) {
    this.data = data;
    this.status = StatusCodes.WAITING;
    this.next = nextState;
    this.prev = prevState;
  }

  changeStatusToProcessing(): void {
    this.data.saveStartTime();
    this.status = StatusCodes.PROCESSING;
  }

  changeStatusToCompleted(): void {
    this.data.saveEndTime();
    this.status = StatusCodes.COMPLETED;
  }

  changeStatusToFailed(): void {
    this.data.saveEndTime();
    this.status = StatusCodes.FAILED;
  }

  reset(): void {
    this.status = StatusCodes.WAITING;
  }

  isFirst(): boolean { return this.prev === null; }

  isLast(): boolean { return this.next === null; }
}